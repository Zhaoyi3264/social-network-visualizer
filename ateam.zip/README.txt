README

Course: cs400
Semester: Fall 2019
Project name: Social Network
Team Members:
1. Carrie Chen, Lec 001, ychen792@wisc.edu
2. Lingzheng He, Lec 001, lhe76@wisc.edu
3. Richard Li, Lec 002, tli354@wisc.edu
4. Zhaoyi Zhang, Lec 001, zzhang825@wisc.edu

Which team members were on same xteam together?
None

Other notes or comments to the grader:
The network shown is hard-coded, so the statistics on the left side does match with the network.
The hard-coded network contains only five people: Carrie, Echo, Richard, Kevin, and Lisa.
All people only have a friendship with Lisa.